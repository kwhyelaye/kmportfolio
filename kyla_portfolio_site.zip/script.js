const items = [
  // Merch
  { id: "merch-01", category: "merch", tag: "Merch Design", title: "Merch Design", src: "assets/page_04.png", thumb: "assets/page_04.png" },

  // Social media postings (multiple pages)
  { id: "social-01", category: "social", tag: "Social Media Postings", title: "Social Media Postings (1)", src: "assets/page_05.png", thumb: "assets/page_05.png" },
  { id: "social-02", category: "social", tag: "Social Media Postings", title: "Social Media Postings (2)", src: "assets/page_06.png", thumb: "assets/page_06.png" },
  { id: "social-03", category: "social", tag: "Social Media Postings", title: "Social Media Postings (3)", src: "assets/page_07.png", thumb: "assets/page_07.png" },
  { id: "social-04", category: "social", tag: "Social Media Postings", title: "Social Media Postings (4)", src: "assets/page_08.png", thumb: "assets/page_08.png" },

  // Posters
  { id: "poster-01", category: "posters", tag: "Graphic Posters", title: "Graphic Poster (1)", src: "assets/page_09.png", thumb: "assets/page_09.png" },
  { id: "poster-02", category: "posters", tag: "Graphic Posters", title: "Graphic Poster (2)", src: "assets/page_10.png", thumb: "assets/page_10.png" },
  { id: "poster-03", category: "posters", tag: "Graphic Posters", title: "Graphic Poster (3)", src: "assets/page_11.png", thumb: "assets/page_11.png" },
];

const gallery = document.getElementById("gallery");
const filters = Array.from(document.querySelectorAll(".filter"));

const lb = document.getElementById("lightbox");
const lbImg = document.getElementById("lbImg");
const lbTitle = document.getElementById("lbTitle");
const lbTag = document.getElementById("lbTag");

let activeFilter = "all";
let activeList = items.slice();
let activeIndex = 0;

function render(){
  const list = activeFilter === "all" ? items : items.filter(i => i.category === activeFilter);
  activeList = list;

  gallery.innerHTML = list.map((it, idx) => `
    <article class="item" data-idx="${idx}" tabindex="0" role="button" aria-label="Open ${it.title}">
      <div class="badge">${it.tag}</div>
      <div class="item__img"><img src="${it.thumb}" alt="${it.title}" loading="lazy" /></div>
      <div class="item__body">
        <div class="item__tag">${it.tag}</div>
        <div class="item__title">${it.title}</div>
      </div>
    </article>
  `).join("");

  // Click + keyboard open
  gallery.querySelectorAll(".item").forEach(card => {
    card.addEventListener("click", () => openAt(parseInt(card.dataset.idx, 10)));
    card.addEventListener("keydown", (e) => {
      if(e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        openAt(parseInt(card.dataset.idx, 10));
      }
    });
  });
}

function setFilter(f){
  activeFilter = f;
  filters.forEach(b => {
    const on = b.dataset.filter === f;
    b.classList.toggle("is-active", on);
    b.setAttribute("aria-selected", on ? "true" : "false");
  });
  render();
}

function openAt(idx){
  activeIndex = idx;
  const it = activeList[activeIndex];
  lbImg.src = it.src;
  lbImg.alt = it.title;
  lbTitle.textContent = it.title;
  lbTag.textContent = it.tag;

  lb.classList.add("is-open");
  lb.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function close(){
  lb.classList.remove("is-open");
  lb.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function prev(){
  activeIndex = (activeIndex - 1 + activeList.length) % activeList.length;
  openAt(activeIndex);
}
function next(){
  activeIndex = (activeIndex + 1) % activeList.length;
  openAt(activeIndex);
}

// Filter buttons
filters.forEach(btn => btn.addEventListener("click", () => setFilter(btn.dataset.filter)));

// Lightbox actions
lb.addEventListener("click", (e) => {
  const t = e.target;
  if(t && t.hasAttribute("data-close")) close();
  if(t && t.hasAttribute("data-prev")) prev();
  if(t && t.hasAttribute("data-next")) next();
});

document.addEventListener("keydown", (e) => {
  if(!lb.classList.contains("is-open")) return;
  if(e.key === "Escape") close();
  if(e.key === "ArrowLeft") prev();
  if(e.key === "ArrowRight") next();
});

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Initial
render();
